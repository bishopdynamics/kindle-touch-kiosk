#!/bin/sh

echo "removing kiosk from autostart"
mntroot rw
rm /etc/upstart/kiosk.conf
mntroot ro

echo "done, next reboot will just go to normal gui"
