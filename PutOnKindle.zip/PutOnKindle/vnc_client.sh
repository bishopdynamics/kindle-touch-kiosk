#!/bin/bash

# execute the vnc client using the details in vnc_config.txt

# config details are in a separate file to make them easeir to edit
source /mnt/us/vnc_config.txt

echo "##########  showing battery status"
/mnt/us/extensions/BatteryStatus/bin/battery-status.sh print_detailed_status

echo "##########  delaying for $STARTUP_DELAY seconds..."
sleep "$STARTUP_DELAY"  # this also is helpful if server is down. so we arent restarting things as often

echo "##########  launching the vnc client -> ${VNC_SERVER}:${VNC_PORT}"
# if we cannot cd to the folder, then nothing else will work either
cd /mnt/us/kvncviewer || exit 1
./luajit vncviewer.lua -password "$VNC_PASSWORD" -reconnecting ${VNC_SERVER}:${VNC_PORT} & PID_CLIENT=$!

echo "##########  the vnc client has been launched with pid: $PID_CLIENT"

wait $PID_CLIENT
echo "##########  the vnc client has quit"
