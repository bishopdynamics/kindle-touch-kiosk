#!/bin/sh

echo "setting kiosk mode to autostart"
mntroot rw
cp kiosk.conf /etc/upstart/kiosk.conf
mntroot ro

echo "done. next reboot will go to kiosk mode"
echo "you can also run: start kiosk"
echo "do undo this, run: ./undo_kiosk_autostart.sh"
